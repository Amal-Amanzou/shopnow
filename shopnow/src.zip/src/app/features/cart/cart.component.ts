import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CartService } from '../../core/services/cart.service';
import { HeaderComponent } from '../../shared/components/header/header.component';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterLink, HeaderComponent],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {

  constructor(public cartService: CartService) {}

  cartItems  = computed(() => this.cartService.cartItems());
  cartTotal  = computed(() => this.cartService.cartTotal());
  cartCount  = computed(() => this.cartService.cartCount());

  onRemove(index: number): void {
    this.cartService.removeFromCart(index);
  }

  onQuantityChange(index: number, delta: number): void {
    const item = this.cartService.cartItems()[index];
    this.cartService.updateQuantity(index, item.quantity + delta);
  }

  onClear(): void {
    this.cartService.clearCart();
  }
}